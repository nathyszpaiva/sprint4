using System.Data.Common;

namespace LHPet.Models
{
    public class Contexto : DBContext
    {
        public Contexto(DbContextOperations<Contexto>options) : base(options)
        {

        }
        public DbSet<Cliente> Cliente { get; set; }
    }
}