
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LHPet.Models
{
    [Table("Cliente")]
    public class Cliente
    {
        
        [Column("Nome")]
        [Display(Nome = Nome)]
        public int Nome { get; set; }

        [Key]
        [Column("User")]
        [Display(User = User)]
        public int User { get; set; }
        

        
        [Column("Email")]
        [Display(Email = Email)]
        public int Email { get; set; }

        
        [Column("Senha")]
        [Display(Senha = Senha)]
        public int Senha { get; set; }

        
        [Column("Telefone")]
        [Display(Telefone = Telefone)]
        public int Telefone { get; set; }

        [Key]
        [Column("Cep")]
        [Display(Cep = Cep)]
        public int Cep { get; set; }
    }
}
